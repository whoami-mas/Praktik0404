﻿using Praktik0404;
using Praktik0404.Classes;

try
{
    var bmi = new Bmi();

    var minValue = 0; //минимальный элемент массива
    var maxValue = 0; //максимальный элемент массива

    var array = RandomArray.GetRandomArray(0, 10,40);

    for (int i = 0; i < array.Length; i++)
    {
        Console.Write(array[i] + " ");
    }
    Console.WriteLine("\nSort Array:");
    RandomArray.SortArray(ref array);
    for (int i = 0; i < array.Length; i++)
    {
        Console.Write(array[i] + " ");
    }

    Console.WriteLine();
    Console.WriteLine($"min value massive:{minValue}\n" +
        $"max value massive:{maxValue}\n");

    ClearGarbage();


    //var middleLengthLine = new MiddleLength(Console.ReadLine());
    //Console.WriteLine(middleLengthLine.MiddleNumber());


    //var waight = ReadFromConsole("Enter waight");
    //   var height = ReadFromConsole("Enter height");

    //Console.WriteLine(bmi.GetBMI(waight, height));

    ClearGarbage();

    Console.ReadKey();
}
catch (ArgumentException ex)
{
    Console.WriteLine(ex.Message);
}

/// <summary>
/// Считывание данных
/// </summary>
double ReadFromConsole(string message)
{
	Console.WriteLine(message);

	return Convert.ToDouble(Console.ReadLine());
}

/// <summary>
/// Очищение мусора
/// </summary>
void ClearGarbage()
{
    var memory = GC.GetTotalMemory(false);
    GC.Collect(1,GCCollectionMode.Optimized);
    GC.WaitForPendingFinalizers();
}
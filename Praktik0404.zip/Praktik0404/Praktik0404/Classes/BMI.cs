﻿namespace Praktik0404.Classes
{
    /// <summary>
    /// Вычисление индекса массы тела с выводом описания.
    /// </summary>
    public class Bmi
    {
        /// <summary>
        /// Минимальный вес. Кг.
        /// </summary>
        private const int minWeight = 30;
        private const int maxWeight = 200;
        /// <summary>
        /// Минимальный рост. См.
        /// </summary>
        private const int minHeight = 110;
        private const int maxHeight = 400;


        /// <summary>
        /// Получение индекса массы тела.
        /// </summary>
        /// <param name="weight"> вес в Кг.</param>
        /// <param name="height"> рост в См.</param>
        /// <returns></returns>
        /// <exception cref="ArgumentOutOfRangeException"></exception>
        public double GetBmi(double weight, double height)
        {
            CheckRange(weight, minWeight, maxWeight);
            CheckRange(height, minHeight, maxHeight);

            height = height / 100;
            var result = weight / (height * height);


            return Math.Round(result, 2);
        }

        private void CheckRange(double value, int min, int max)
        {
            if (value <= min || value >= max)
            {
                throw new ArgumentOutOfRangeException(nameof(value), $"Enter valid values weight\nEnter data range {min}-{max}");
            }
        }

        Dictionary<double, string> bmiDescriptions = new Dictionary<double, string>()
        {
            {16,"body weight deficit" },
            {18.5,"body weight deficit" },
            {24.55,"body weight deficit" },
            {30,"body weight deficit" },
            {35,"body weight deficit" },
            {40,"body weight deficit" }
        };

        /// <summary>
        /// Вывод описания по индексу массы тела.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public string GetDescription(double index)
        {
            foreach (var item in bmiDescriptions)
            {
                if (index <= item.Key)
                {
                    return item.Value;
                }
            }

            return "obesity of the third degree";
        }
    }
}

﻿namespace Praktik0404.Classes
{
    /// <summary>
    /// Составление массива с рандомными элементами, сортировкой, нахождением минимального и максимального элементов.
    /// </summary>
    static class RandomArray
    {
        /// <summary>
        /// Минимальный размер массива.
        /// </summary>
        const int minSizeArray = 1;
        /// <summary>
        /// Максимальный размер массива.
        /// </summary>
        const int maxSizeArray = 100;
        /// <summary>
        /// Генерируем массив и соритрируем его.
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <returns></returns>
        public static int[] GetRandomArray(int min, int max, int size)
        {
            #region Валидация.
            if (min > max)
            {
                throw new ArgumentException("", nameof(min));
            }

            if (size <= minSizeArray)
            {
                throw new ArgumentNullException(nameof(size), "Min value");
            }

            if (size >= maxSizeArray)
            {
                throw new ArgumentNullException(nameof(size), "Max value");
            }
            #endregion

            var random = new Random();
            var array = new int[size];

            for (var i = 0; i < size; i++)
            {
                array[i] = random.Next(min, max);
            }

            return array;
        }

        /// <summary>
        /// Сортирует массив.
        /// </summary>
        /// <param name="array"></param>
        public static void SortArray(ref int[] array)
        {
            CheckArray(array);

            for (var i = 0; i < array.Length; i++)
            {
                int smallPosition = FindSmallElement(array, i);

                var element = array[i];
                array[i] = array[smallPosition];
                array[smallPosition] = element;
            }
        }

        /// <summary>
        /// Находим наименьшее значение.
        /// </summary>
        /// <param name="array"></param>
        /// <param name="startPosition"></param>
        /// <returns></returns>
        private static int FindSmallElement(int[] array, int startPosition)
        {
            CheckArray(array);

           
            for (var i = startPosition; i < array.Length; i++)
            {
                if (array[i] < array[startPosition])
                {
                    startPosition = i;
                }
            }

            return startPosition;
        }

        /// <summary>
        /// Проверка массива на пустоту.
        /// </summary>
        /// <param name="array"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public static void CheckArray(int[] array)
        {
            if (array is null)
            {
                throw new ArgumentNullException(nameof(array), "Null array");
            }
        }

        /// <summary>
        /// Проверка на заполненность массива.
        /// </summary>
        /// <param name="array"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public static void CheckArrayNotEmpty(int[] array)
        {
            if (array is null || array.Length == 0)
            {
                throw new ArgumentNullException(nameof(array), "Null array");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praktik0404.Classes
{

    public struct AverageLength
    {
        public string line;

        public AverageLength(string line)
        {
            this.line = line;
        }

        /// <summary>
        /// Получение средней длины слова.
        /// </summary>
        /// <returns></returns>
        public decimal GetAverageGen()
        {
            var length=0;

            foreach (var item in line)
            {
                if (Char.IsLetter(item))
                {
                    length++;
                }
            }

            return (decimal)length / 2;
        }
    }
}
